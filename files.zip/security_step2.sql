-- =====================================================
-- تأمين شامل (الخطة 2)
-- نفّذ هذا الملف في: Supabase Dashboard -> SQL Editor -> New query -> Run
-- شرط أساسي: أنشأت مستخدم أدمن من Authentication -> Users (مع Auto Confirm User)
-- =====================================================

-- التأكد من تفعيل RLS على الجدولين
alter table public.students enable row level security;
alter table public.invitations enable row level security;

-- إزالة السياسات العامة القديمة (التي كانت تسمح لأي زائر بالوصول الكامل)
-- ملاحظة: إن لم يكن أحد هذه الأسماء موجوداً سيتم تجاهله بأمان
drop policy if exists "Allow public full access students" on public.students;
drop policy if exists "Allow public read students" on public.students;
drop policy if exists "Allow public full access invitations" on public.invitations;
drop policy if exists "Allow public read" on public.invitations;
drop policy if exists "Allow update used" on public.invitations;

-- سياسات جديدة: الوصول الكامل (قراءة/إضافة/تعديل/حذف) فقط لمن سجّل دخوله
-- عبر Supabase Auth (لوحة التحكم بعد تسجيل الدخول)
create policy "Authenticated full access students"
on public.students
for all
to authenticated
using (true)
with check (true);

create policy "Authenticated full access invitations"
on public.invitations
for all
to authenticated
using (true)
with check (true);

-- ملاحظة: سياسة "Block direct check-in" المنشأة في الخطة 1 تبقى كما هي وتعمل تلقائياً
-- (تمنع تعيين used = true مباشرة، حتى للمستخدم المسجل دخوله، وتسمح فقط بـ used = false
--  وبدالة check_in_invitation الآمنة)

-- الزوار العامون (anon) لا يملكون أي صلاحية مباشرة على الجدولين الآن،
-- لكن صفحة scan.html تستمر بالعمل بشكل طبيعي عبر دالة check_in_invitation
-- لأنها SECURITY DEFINER وتتجاوز RLS، وصلاحية تنفيذها ممنوحة لـ anon من الخطة 1.
